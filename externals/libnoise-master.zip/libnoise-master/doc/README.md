Building doco
-------------

Run doxygen from this directory.

Copy the following files from the htmldata into the html subdirectory:

 * background.png
 * doxygen.css
 * libnoise.png

The HTML documentation contains custom headers and footers that require
certain image files to exist in the html subdirectory.  I don't know how to
get doxygen to copy these files automagically.

-- jas
